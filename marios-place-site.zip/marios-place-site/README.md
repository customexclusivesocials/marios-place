# Mario's Place website

Single-page site for Mario's Place, 177 E Main St, Welland, ON.

## Publish on GitHub Pages
1. Create a new repository and upload everything in this folder (keep `index.html` and the `images` folder together at the top level).
2. Go to Settings > Pages, set Source to "Deploy from a branch", choose `main` and `/ (root)`, then Save.
3. The site goes live at `https://USERNAME.github.io/REPO/` in a minute or two. Add a custom domain under the same Pages settings.

## Edit
- Menu items and prices: the `MENU` array near the bottom of `index.html`.
- Hours: the hours table, plus the `H` object in the script (used for the open-now badge).
- Photo: replace `images/joe.jpg`.
